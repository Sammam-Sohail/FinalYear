mostly there are 4 targets
sometimes 5 but cant get 5 targets

3_csv done


done-14Dec